-- ============================================================================
-- Pleasantview: STEP 1 of 2 — install the sign-in and safe-saving functions
--
-- Safe to run: it adds new tables and functions only. It does NOT change who can
-- see your data. Your current apps keep working exactly as they do today.
-- Running it twice is harmless.
-- ============================================================================

-- ---------- sign-in sessions and login attempts (not readable from the apps) ----------
create table if not exists public.app_sessions (
  token_hash text primary key,
  role       text not null,              -- owner | employee | accountant
  name       text not null,
  emp_role   text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create table if not exists public.app_login_attempts (
  who          text primary key,
  fails        int not null default 0,
  locked_until timestamptz
);
alter table public.app_sessions enable row level security;
alter table public.app_login_attempts enable row level security;
revoke all on public.app_sessions from anon, authenticated;
revoke all on public.app_login_attempts from anon, authenticated;

-- ---------- internal helpers (not callable from the apps) ----------
create or replace function public.app_who(p_token text)
returns public.app_sessions
language plpgsql security definer set search_path = public as $$
declare s public.app_sessions;
begin
  select * into s from public.app_sessions
   where token_hash = encode(sha256(convert_to(coalesce(p_token, ''), 'UTF8')), 'hex')
     and expires_at > now();
  if not found then raise exception 'unauthorized'; end if;
  return s;
end $$;

-- Who may read or write which key. Owner: everything. Anything not listed is denied for everyone else.
create or replace function public.app_can(p_role text, p_name text, p_key text, p_write boolean)
returns boolean
language sql immutable set search_path = public as $$
  select case p_role
    when 'owner' then true
    when 'accountant' then (not p_write) and p_key like 'pvb-%'
    when 'employee' then
      case when p_write then
        p_key in ('pps-summer','pps-winter','pps-carries','pps-snowdays','pps-shifts','pps-paused')
        or p_key like 'pps-dsub-%'
        or p_key = 'pps-loc-' || regexp_replace(lower(btrim(p_name)), '[^a-z0-9]+', '-', 'g')
      else
        p_key in ('pps-clients','pps-employees','pps-summer','pps-winter','pps-carries','pps-snowdays','pps-shifts','pps-paused')
      end
    else false
  end
$$;

-- Combine two saves of the same visit without losing either person's work
create or replace function public.app_merge_visit(p_old jsonb, p_new jsonb, p_untick jsonb)
returns jsonb
language plpgsql immutable set search_path = public as $$
declare
  r jsonb;
  o_tasks jsonb := coalesce(p_old->'tasks', '{}'::jsonb);
  n_tasks jsonb := coalesce(p_new->'tasks', '{}'::jsonb);
  tasks jsonb; ts jsonb; reasons jsonb; log jsonb; photos jsonb; k text;
begin
  -- everything except the special fields: the newest save wins; the original id, logger and time are kept
  r := p_old || (p_new - 'tasks' - 'taskReasons' - 'taskTimestamps' - 'taskLog' - 'photos'
                       - 'id' - 'loggedBy' - 'loggedAt' - 'location');
  if p_old ? 'location' then r := r || jsonb_build_object('location', p_old->'location');
  elsif p_new ? 'location' then r := r || jsonb_build_object('location', p_new->'location'); end if;

  -- a task is done if either save says so, unless this save explicitly un-ticked it
  select coalesce(jsonb_object_agg(key, to_jsonb(
           ((coalesce(o_tasks->>key, 'false'))::boolean or (coalesce(n_tasks->>key, 'false'))::boolean)
           and not jsonb_exists(p_untick, key))), '{}'::jsonb)
    into tasks
    from (select jsonb_object_keys(o_tasks) as key union select jsonb_object_keys(n_tasks)) q;
  r := r || jsonb_build_object('tasks', tasks);

  ts      := coalesce(p_old->'taskTimestamps', '{}'::jsonb) || coalesce(p_new->'taskTimestamps', '{}'::jsonb);
  reasons := coalesce(p_old->'taskReasons',    '{}'::jsonb) || coalesce(p_new->'taskReasons',    '{}'::jsonb);
  log     := coalesce(p_new->'taskLog',        '{}'::jsonb) || coalesce(p_old->'taskLog',        '{}'::jsonb); -- first person to complete a task keeps the credit
  for k in select jsonb_array_elements_text(coalesce(p_untick, '[]'::jsonb)) loop
    if left(k, 6) <> 'photo:' then ts := ts - k; log := log - k; end if;
  end loop;
  r := r || jsonb_build_object('taskTimestamps', ts, 'taskReasons', reasons, 'taskLog', log);

  -- photos: everything from both saves, minus any this save removed
  select coalesce(jsonb_agg(p order by ord), '[]'::jsonb) into photos
    from (
      select p, row_number() over () as ord from (
        select p from jsonb_array_elements(coalesce(p_old->'photos', '[]'::jsonb)) p
        union all
        select p from jsonb_array_elements(coalesce(p_new->'photos', '[]'::jsonb)) p
         where not exists (select 1 from jsonb_array_elements(coalesce(p_old->'photos', '[]'::jsonb)) o where o->>'id' = p->>'id')
      ) u
    ) z
   where not jsonb_exists(p_untick, 'photo:' || coalesce(p->>'id', ''));
  r := r || jsonb_build_object('photos', photos);

  return r;
end $$;

-- ---------- public entry points ----------

-- Names for the "Who are you?" screen (no PINs)
create or replace function public.app_employee_names()
returns jsonb
language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', e->'id', 'name', e->'name', 'role', e->'role')), '[]'::jsonb)
    from public.app_data d, jsonb_array_elements(d.value) e
   where d.key = 'pps-employees' and jsonb_typeof(d.value) = 'array'
$$;

-- Has an owner PIN been created yet? (true/false only, never the PIN)
create or replace function public.app_owner_pin_set()
returns boolean
language sql security definer set search_path = public as $$
  select exists (select 1 from public.app_data where key = 'pps-ownerpin')
$$;

-- Sign in with a name and PIN. Five wrong PINs lock that name for 10 minutes.
create or replace function public.app_login(p_name text, p_pin text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_who text := lower(btrim(coalesce(p_name, '')));
  v_pin text := btrim(coalesce(p_pin, ''));
  v_att public.app_login_attempts;
  v_role text; v_name text; v_emp_role text; v_ok boolean := false;
  v_stored jsonb; e jsonb; v_token text;
begin
  if v_who = '' or v_pin = '' then return jsonb_build_object('ok', false, 'error', 'bad_pin'); end if;
  select * into v_att from public.app_login_attempts where who = v_who;
  if found and v_att.locked_until is not null and v_att.locked_until > now() then
    return jsonb_build_object('ok', false, 'error', 'locked',
                              'minutes', greatest(1, ceil(extract(epoch from (v_att.locked_until - now())) / 60)::int));
  end if;

  if v_who = 'owner' then
    select value into v_stored from public.app_data where key = 'pps-ownerpin';
    if v_stored is null then return jsonb_build_object('ok', false, 'error', 'no_owner_pin'); end if;
    v_ok := btrim(v_stored #>> '{}') = v_pin; v_role := 'owner'; v_name := 'Owner'; v_emp_role := 'all';
  elsif v_who = 'accountant' then
    select value->>'accountantPin' into v_stored from public.app_data where key = 'pvb-settings';
    v_ok := v_stored is not null and btrim(v_stored #>> '{}') <> '' and btrim(v_stored #>> '{}') = v_pin;
    v_role := 'accountant'; v_name := 'Accountant'; v_emp_role := 'all';
  else
    select value into v_stored from public.app_data where key = 'pps-employees';
    if v_stored is not null and jsonb_typeof(v_stored) = 'array' then
      for e in select * from jsonb_array_elements(v_stored) loop
        if lower(btrim(coalesce(e->>'name', ''))) = v_who and btrim(coalesce(e->>'pin', '')) <> '' and btrim(e->>'pin') = v_pin then
          v_ok := true; v_role := 'employee'; v_name := e->>'name'; v_emp_role := coalesce(e->>'role', 'all'); exit;
        end if;
      end loop;
    end if;
  end if;

  if not v_ok then
    insert into public.app_login_attempts(who, fails) values (v_who, 1)
      on conflict (who) do update set fails = public.app_login_attempts.fails + 1;
    update public.app_login_attempts
       set locked_until = now() + interval '10 minutes', fails = 0
     where who = v_who and fails >= 5;
    return jsonb_build_object('ok', false, 'error', 'bad_pin');
  end if;

  delete from public.app_login_attempts where who = v_who;
  delete from public.app_sessions where expires_at < now();
  v_token := replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', '');
  insert into public.app_sessions(token_hash, role, name, emp_role, expires_at)
    values (encode(sha256(convert_to(v_token, 'UTF8')), 'hex'), v_role, v_name, v_emp_role, now() + interval '60 days');
  return jsonb_build_object('ok', true, 'token', v_token, 'role', v_role, 'name', v_name, 'empRole', v_emp_role);
end $$;

create or replace function public.app_logout(p_token text)
returns boolean
language sql security definer set search_path = public as $$
  delete from public.app_sessions where token_hash = encode(sha256(convert_to(coalesce(p_token, ''), 'UTF8')), 'hex');
  select true
$$;

-- First-ever owner PIN (only works while no owner PIN exists)
create or replace function public.app_setup_owner(p_pin text)
returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from public.app_data where key = 'pps-ownerpin') then
    return jsonb_build_object('ok', false, 'error', 'already_set');
  end if;
  if length(btrim(coalesce(p_pin, ''))) < 4 then return jsonb_build_object('ok', false, 'error', 'too_short'); end if;
  insert into public.app_data(key, value, updated_at) values ('pps-ownerpin', to_jsonb(btrim(p_pin)), now());
  return public.app_login('Owner', p_pin);
end $$;

-- Read one key
create or replace function public.app_get(p_token text, p_key text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare s public.app_sessions; v jsonb;
begin
  s := public.app_who(p_token);
  if not public.app_can(s.role, s.name, p_key, false) then raise exception 'forbidden'; end if;
  select value into v from public.app_data where key = p_key;
  if v is null then return null; end if;
  if s.role = 'employee' and jsonb_typeof(v) = 'array' then
    if p_key = 'pps-clients' then   -- employees never receive client phone numbers or emails
      select coalesce(jsonb_agg(c - 'phone' - 'email'), '[]'::jsonb) into v from jsonb_array_elements(v) c;
    elsif p_key = 'pps-employees' then   -- ... or anyone's PIN
      select coalesce(jsonb_agg(jsonb_build_object('id', e->'id', 'name', e->'name', 'role', e->'role')), '[]'::jsonb) into v from jsonb_array_elements(v) e;
    end if;
  end if;
  return v;
end $$;

-- Write one key
create or replace function public.app_set(p_token text, p_key text, p_value jsonb)
returns boolean
language plpgsql security definer set search_path = public as $$
declare s public.app_sessions;
begin
  s := public.app_who(p_token);
  if not public.app_can(s.role, s.name, p_key, true) then raise exception 'forbidden'; end if;
  insert into public.app_data(key, value, updated_at) values (p_key, p_value, now())
    on conflict (key) do update set value = excluded.value, updated_at = now();
  return true;
end $$;

-- List keys by prefix (owner only): live positions, backups
create or replace function public.app_list(p_token text, p_prefix text, p_mode text default 'value')
returns jsonb
language plpgsql security definer set search_path = public as $$
declare s public.app_sessions; out jsonb;
begin
  s := public.app_who(p_token);
  if s.role <> 'owner' then raise exception 'forbidden'; end if;
  if p_mode = 'counts' then
    select coalesce(jsonb_agg(jsonb_build_object('key', key, 'updated_at', updated_at, 'counts', value->'counts') order by updated_at desc), '[]'::jsonb)
      into out from public.app_data where key like replace(replace(p_prefix, '%', ''), '_', '\_') || '%';
  else
    select coalesce(jsonb_agg(jsonb_build_object('key', key, 'updated_at', updated_at, 'value', value) order by key), '[]'::jsonb)
      into out from (select * from public.app_data where key like replace(replace(p_prefix, '%', ''), '_', '\_') || '%' limit 500) t;
  end if;
  return out;
end $$;

-- Save one visit. Two people finishing the same property at the same moment are merged, never overwritten.
-- p_untick lists task keys (and "photo:<id>") that THIS save removed on purpose. p_replace = true replaces the visit outright (owner edits).
create or replace function public.app_save_visit(p_token text, p_key text, p_visit jsonb, p_untick jsonb default '[]'::jsonb, p_replace boolean default false)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  s public.app_sessions; cur jsonb; elem jsonb; i int := 0; idx int := -1; merged jsonb; arr jsonb;
begin
  s := public.app_who(p_token);
  if p_key not in ('pps-summer', 'pps-winter') then raise exception 'forbidden'; end if;
  if not public.app_can(s.role, s.name, p_key, true) then raise exception 'forbidden'; end if;
  if p_replace and s.role <> 'owner' then p_replace := false; end if;

  insert into public.app_data(key, value, updated_at) values (p_key, '[]'::jsonb, now()) on conflict (key) do nothing;
  select value into cur from public.app_data where key = p_key for update;       -- lock: one save at a time
  if jsonb_typeof(cur) <> 'array' then cur := '[]'::jsonb; end if;

  for elem in select * from jsonb_array_elements(cur) loop
    if (elem->>'clientId' = p_visit->>'clientId' and elem->>'date' = p_visit->>'date')
       or (p_visit ? 'id' and elem->>'id' = p_visit->>'id') then idx := i; exit; end if;
    i := i + 1;
  end loop;

  if idx >= 0 then
    elem := cur->idx;
    if p_replace then merged := p_visit || jsonb_build_object('id', elem->'id');
    else merged := public.app_merge_visit(elem, p_visit, coalesce(p_untick, '[]'::jsonb)); end if;
    select jsonb_agg(case when ord - 1 = idx then merged else e end order by ord) into arr
      from jsonb_array_elements(cur) with ordinality t(e, ord);
  else
    merged := p_visit; arr := cur || jsonb_build_array(merged);
  end if;
  update public.app_data set value = arr, updated_at = now() where key = p_key;
  return merged;
end $$;

-- Delete one visit by id
create or replace function public.app_delete_visit(p_token text, p_key text, p_id text)
returns boolean
language plpgsql security definer set search_path = public as $$
declare s public.app_sessions;
begin
  s := public.app_who(p_token);
  if p_key not in ('pps-summer', 'pps-winter') or not public.app_can(s.role, s.name, p_key, true) then raise exception 'forbidden'; end if;
  update public.app_data
     set value = coalesce((select jsonb_agg(e order by ord) from jsonb_array_elements(value) with ordinality t(e, ord) where e->>'id' is distinct from p_id), '[]'::jsonb),
         updated_at = now()
   where key = p_key and jsonb_typeof(value) = 'array';
  return true;
end $$;

-- ---------- who may call what ----------
revoke all on function public.app_who(text) from public, anon, authenticated;
revoke all on function public.app_can(text, text, text, boolean) from public, anon, authenticated;
revoke all on function public.app_merge_visit(jsonb, jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.app_employee_names() to anon, authenticated;
grant execute on function public.app_owner_pin_set() to anon, authenticated;
grant execute on function public.app_login(text, text) to anon, authenticated;
grant execute on function public.app_logout(text) to anon, authenticated;
grant execute on function public.app_setup_owner(text) to anon, authenticated;
grant execute on function public.app_get(text, text) to anon, authenticated;
grant execute on function public.app_set(text, text, jsonb) to anon, authenticated;
grant execute on function public.app_list(text, text, text) to anon, authenticated;
grant execute on function public.app_save_visit(text, text, jsonb, jsonb, boolean) to anon, authenticated;
grant execute on function public.app_delete_visit(text, text, text) to anon, authenticated;
