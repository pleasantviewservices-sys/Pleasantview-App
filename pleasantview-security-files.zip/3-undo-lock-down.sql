-- Puts things back exactly as they were before the lock (open access). Use only in an emergency.
grant select, insert, update, delete on public.app_data to anon, authenticated;
alter table public.app_data enable row level security;
drop policy if exists "Allow all" on public.app_data;
create policy "Allow all" on public.app_data for all using (true) with check (true);
