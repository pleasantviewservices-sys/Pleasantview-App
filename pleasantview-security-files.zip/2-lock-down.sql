-- ============================================================================
-- Pleasantview: STEP 2 of 2 — LOCK THE DATA
--
-- Run this ONLY after the new apps (crew + Books) are uploaded to GitHub and
-- you have signed in on them once. After this, the old apps/links stop working
-- and nobody can read or change your data without signing in.
-- To go back at any time, run 3-undo-lock-down.sql.
-- ============================================================================
drop policy if exists "Allow all" on public.app_data;
alter table public.app_data enable row level security;
revoke all on public.app_data from anon, authenticated;
-- (no policy = the public key can no longer read or write the table directly;
--  the apps now go through the sign-in functions installed in step 1)
