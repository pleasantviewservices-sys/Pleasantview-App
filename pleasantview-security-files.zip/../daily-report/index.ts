// Supabase Edge Function: daily-report
// Builds ONE combined end-of-day report for the whole crew and emails it.
//   - Nightly at 11:59pm Toronto time, called by pg_cron (see schedule.sql)
//   - On demand from the app: Admin, then "Send Today's Report" (owner PIN required)
// Secrets: GMAIL_USER, GMAIL_APP_PASSWORD, DAILY_REPORT_SECRET, optional REPORT_TO
// (SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided automatically)
import nodemailer from "npm:nodemailer@6.9.14";
import { createClient } from "npm:@supabase/supabase-js@2";

const TZ = "America/Toronto";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-secret", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });
const esc = (s: unknown) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]!));

const LABELS: Record<string, string> = {
  debrisCollected: "Debris collected", lawnMowed: "Lawn mowed", perimeterTrimmed: "Perimeter trimmed", gardensWeeded: "Gardens weeded",
  hedgesTrimmed: "Hedges & bushes trimmed", leavesCollected: "Leaves collected", propertyBlown: "Property blown",
  lotPlowed: "Parking lot plowed", lotSalted: "Parking lot salted", walkwaysShoveled: "Walkways shoveled", walkwaysSalted: "Walkways salted",
  saltBinsFilled: "Salt bins filled", propertyCheck: "Property check",
};
const label = (k: string) => LABELS[k] || k.replace(/([A-Z])/g, " $1").replace(/^./, (c) => c.toUpperCase());
const dateOf = (iso: string) => new Date(iso).toLocaleDateString("en-CA", { timeZone: TZ });
const timeOf = (iso: string) => new Date(iso).toLocaleTimeString("en-CA", { timeZone: TZ, hour: "numeric", minute: "2-digit", hour12: true }).replace(/\./g, "").replace(/\s/g, " ");
const locHtml = (l: any) => l && isFinite(Number(l.lat)) && isFinite(Number(l.lng))
  ? `<div style="font-size:12px;color:#444;margin:0 0 8px;">Finished at ${l.at ? esc(timeOf(l.at)) : ""}: <a href="https://www.google.com/maps?q=${Number(l.lat)},${Number(l.lng)}" style="color:#1d4ed8;text-decoration:none;font-weight:600;">${esc(l.address || (Number(l.lat) + ", " + Number(l.lng)))}</a> <span style="color:#888;">· GPS ${Number(l.lat)}, ${Number(l.lng)}${Number(l.acc) ? " (±" + Number(l.acc) + " m)" : ""}</span></div>`
  : `<div style="font-size:12px;color:#9ca3af;margin:0 0 8px;">No finish location recorded</div>`;
const locText = (l: any) => l && isFinite(Number(l.lat)) ? `\n  Finished at ${l.at ? timeOf(l.at) : ""}: ${l.address || ""} (GPS ${Number(l.lat)}, ${Number(l.lng)}${Number(l.acc) ? ", ±" + Number(l.acc) + " m" : ""}) https://www.google.com/maps?q=${Number(l.lat)},${Number(l.lng)}` : "\n  No finish location recorded";
const span = (g: { at: string; end: string }) => (g.at ? timeOf(g.at) + (g.end && g.end !== g.at && timeOf(g.end) !== timeOf(g.at) ? " to " + timeOf(g.end) : "") : "");
const prettyDate = (d: string) => new Date(d + "T12:00:00").toLocaleDateString("en-CA", { weekday: "long", month: "long", day: "numeric", year: "numeric" });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ ok: false, error: "POST only" }, 405);
  let body: any = {};
  try { body = await req.json(); } catch { /* empty body from cron is fine */ }

  // Database access: try the legacy service key, then the newer secret keys; report the real error if none work
  const url = Deno.env.get("SUPABASE_URL")!;
  const keys: string[] = [];
  const srk = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (srk) keys.push(srk);
  try { for (const v of Object.values(JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") || "{}"))) if (typeof v === "string") keys.push(v); } catch { /* ignore */ }
  let sb = createClient(url, keys[0] || "");
  let dbError = "no database key available";
  for (const k of keys) {
    const c = createClient(url, k);
    const r: any = await c.from("app_data").select("value").eq("key", "pps-ownerpin").maybeSingle();
    if (!r.error) { sb = c; dbError = ""; break; }
    dbError = String(r.error.message || r.error).slice(0, 120);
  }
  if (dbError) return json({ ok: false, error: "Database access failed: " + dbError }, 500);
  const get = async (key: string) => (await sb.from("app_data").select("value").eq("key", key).maybeSingle()).data?.value;

  // Who is calling: the nightly timer (secret) or the owner (PIN)
  const secret = Deno.env.get("DAILY_REPORT_SECRET");
  const isCron = !!secret && req.headers.get("x-cron-secret") === secret;
  let manual = false;
  if (!isCron) {
    const pin = await get("pps-ownerpin");
    if (!pin || !body.pin || String(pin).trim() !== String(body.pin).trim()) return json({ ok: false, error: "Unauthorized" }, 401);
    manual = true;
  }

  const user = Deno.env.get("GMAIL_USER"), pass = Deno.env.get("GMAIL_APP_PASSWORD");
  if (!user || !pass) return json({ ok: false, error: "not_configured" }, 500);

  // Nightly mode: only act in the 11pm hour Toronto time (the timer fires at two UTC hours to cover daylight saving), once per day
  let date = String(body.date || "");
  if (isCron && !body.force) {
    const hour = parseInt(new Date().toLocaleString("en-CA", { timeZone: TZ, hour: "2-digit", hour12: false }));
    if (hour !== 23) return json({ ok: true, sent: false, reason: "Not 11pm in Toronto yet" });
    date = dateOf(new Date().toISOString());
    if (await get(`pps-dsent-${date}`)) return json({ ok: true, sent: false, reason: "Already sent" });
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) date = dateOf(new Date().toISOString());

  const clients: any[] = (await get("pps-clients")) || [];
  const summer: any[] = (await get("pps-summer")) || [];
  const winter: any[] = (await get("pps-winter")) || [];
  const { data: subRows } = await sb.from("app_data").select("value").like("key", `pps-dsub-${date}-%`);
  const subs: any[] = (subRows || []).map((r: any) => r.value).sort((a: any, b: any) => String(a.submittedAt).localeCompare(String(b.submittedAt)));

  const onDay = (s: any) => (s.loggedAt ? dateOf(s.loggedAt) === date : s.date === date);
  const visits = [...summer.filter(onDay).map((s) => ({ ...s, season: "Summer" })), ...winter.filter(onDay).map((s) => ({ ...s, season: "Winter" }))];
  if (visits.length === 0 && subs.length === 0) return json({ ok: true, sent: false, reason: "Nothing was recorded for " + date });

  // Normalize each visit: tasks grouped by the person who did them
  type Item = { cid: any; name: string; contact: string; address: string; season: string; first: string; groups: { by: string; at: string; end: string; tasks: string[] }[]; undone: string[]; notes: string; weather: string; photos: string[]; photoOnly: number; people: Set<string>; loc: any };
  const items: Item[] = visits.map((s) => {
    const c = clients.find((x) => x.id === s.clientId) || {};
    const log = s.taskLog || {}; const byKey = new Map<string, { by: string; at: string; end: string; tasks: string[] }>();
    const undone: string[] = [];
    Object.entries(s.tasks || {}).forEach(([k, v]) => {
      if (v) {
        const e = log[k] || { by: s.loggedBy || "Unknown", at: s.loggedAt || "" };
        if (!byKey.has(e.by)) byKey.set(e.by, { by: e.by, at: e.at, end: e.at, tasks: [] });
        const g = byKey.get(e.by)!; g.tasks.push(label(k));
        if (e.at && (!g.at || e.at < g.at)) g.at = e.at; if (e.at && e.at > g.end) g.end = e.at;
      } else undone.push(label(k) + (s.taskReasons?.[k] ? ` (${s.taskReasons[k]})` : ""));
    });
    const groups = [...byKey.values()].sort((a, b) => String(a.at).localeCompare(String(b.at)));
    const photos = (s.photos || []).map((p: any) => p.url).filter(Boolean);
    const people = new Set<string>(groups.map((g) => g.by)); if (s.loggedBy) people.add(s.loggedBy);
    return { cid: s.clientId, name: c.businessName || c.name || "Unknown client", contact: c.businessName && c.name ? c.name : "", address: c.address || "", season: s.season, first: s.loggedAt || groups[0]?.at || "", groups, undone, notes: s.notes || "", weather: s.weather || "", photos, photoOnly: (s.photos || []).length - photos.length, people, loc: s.location || null };
  }).sort((a, b) => String(a.first).localeCompare(String(b.first)));

  // Per-person summary
  const crew = new Map<string, { visits: Set<number>; tasks: number; first: string; last: string }>();
  items.forEach((it, i) => it.groups.forEach((g) => {
    const e = crew.get(g.by) || { visits: new Set(), tasks: 0, first: g.at, last: g.at };
    e.visits.add(i); e.tasks += g.tasks.length; if (g.at && (!e.first || g.at < e.first)) e.first = g.at; if (g.at && g.at > e.last) e.last = g.at; crew.set(g.by, e);
  }));
  const submitted = new Set(subs.map((s) => String(s.employee).trim().toLowerCase()));
  const missing: string[] = []; // crew no longer submit a separate report, so there is nothing to flag
  const totalPhotos = items.reduce((t, i) => t + i.photos.length + i.photoOnly, 0);

  const H = (t: string) => `<div style="font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#6b7280;margin:26px 0 8px;">${t}</div>`;
  const crewRows = [...crew.entries()].map(([n, e]) => `<tr><td style="padding:7px 8px;border-bottom:1px solid #eee;font-weight:600;">${esc(n)}</td><td style="padding:7px 8px;border-bottom:1px solid #eee;text-align:center;">${e.visits.size}</td><td style="padding:7px 8px;border-bottom:1px solid #eee;text-align:center;">${e.tasks}</td><td style="padding:7px 8px;border-bottom:1px solid #eee;color:#555;">${e.first ? timeOf(e.first) : ""}${e.last && e.last !== e.first ? " to " + timeOf(e.last) : ""}</td></tr>`).join("");
  const cards = items.map((it) => `
    <div style="border:1px solid #e5e7eb;border-radius:8px;padding:14px 16px;margin-bottom:10px;">
      <div style="font-size:15px;font-weight:700;color:#111;">${esc(it.name)} <span style="font-size:11px;font-weight:600;color:#fff;background:${it.season === "Winter" ? "#3b82f6" : "#4d7c0f"};border-radius:10px;padding:2px 8px;vertical-align:middle;">${it.season}</span></div>
      <div style="font-size:12px;color:#4d7c0f;margin:2px 0 8px;">${esc(it.address)}${it.contact ? ` · <span style="color:#777;">${esc(it.contact)}</span>` : ""}</div>
      ${locHtml(it.loc)}
      ${it.groups.map((g) => `<div style="font-size:13px;color:#222;margin:3px 0;"><b>${esc(g.by)}</b> <span style="color:#777;">${span(g)}</span>: ${esc(g.tasks.join(", "))}</div>`).join("") || `<div style="font-size:13px;color:#999;">No tasks completed</div>`}
      ${it.undone.length ? `<div style="font-size:12px;color:#b45309;margin-top:5px;">Not done: ${esc(it.undone.join(", "))}</div>` : ""}
      ${it.weather ? `<div style="font-size:12px;color:#777;margin-top:4px;">Weather: ${esc(it.weather)}</div>` : ""}
      ${it.notes ? `<div style="font-size:13px;color:#333;background:#f9fafb;border-radius:6px;padding:8px 10px;margin-top:8px;">${esc(it.notes)}</div>` : ""}
      ${it.photos.length ? `<div style="margin-top:8px;">${it.photos.slice(0, 6).map((u) => `<a href="${esc(u)}"><img src="${esc(u)}" width="96" height="96" style="object-fit:cover;border-radius:6px;margin:0 6px 6px 0;border:1px solid #ddd;"></a>`).join("")}${it.photos.length > 6 ? `<div style="font-size:12px;color:#777;">+${it.photos.length - 6} more photos</div>` : ""}</div>` : ""}
    </div>`).join("");
  const notesHtml = subs.map((s) => `<div style="border-left:3px solid #4d7c0f;padding:4px 12px;margin:0 0 10px;"><div style="font-size:13px;font-weight:700;color:#111;">${esc(s.employee)} <span style="font-weight:400;color:#777;">submitted ${timeOf(s.submittedAt)}</span></div><div style="font-size:13px;color:#333;">${s.notes ? esc(s.notes) : '<span style="color:#999;">No additional notes</span>'}</div></div>`).join("");

  const html = `<div style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;max-width:640px;margin:0 auto;color:#111;">
    <div style="font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:#6b7280;">Pleasantview Property Services</div>
    <div style="font-size:22px;font-weight:700;margin:2px 0 4px;">Daily report</div>
    <div style="font-size:14px;color:#555;">${prettyDate(date)}</div>
    <div style="font-size:14px;margin-top:12px;"><b>${items.length}</b> visit${items.length === 1 ? "" : "s"} · <b>${new Set(items.map((i) => i.cid)).size}</b> propert${new Set(items.map((i) => i.cid)).size === 1 ? "y" : "ies"} · <b>${crew.size}</b> crew member${crew.size === 1 ? "" : "s"} · <b>${totalPhotos}</b> photo${totalPhotos === 1 ? "" : "s"}</div>
    ${missing.length ? `<div style="font-size:13px;color:#b45309;background:#fffbeb;border:1px solid #fde68a;border-radius:6px;padding:8px 10px;margin-top:12px;">Logged work but did not submit a report: ${esc(missing.join(", "))}</div>` : ""}
    ${crew.size ? H("Crew") + `<table style="width:100%;border-collapse:collapse;font-size:13px;"><tr style="color:#6b7280;font-size:11px;text-transform:uppercase;"><td style="padding:4px 8px;">Name</td><td style="padding:4px 8px;text-align:center;">Visits</td><td style="padding:4px 8px;text-align:center;">Tasks</td><td style="padding:4px 8px;">Time on site</td></tr>${crewRows}</table>` : ""}
    ${items.length ? H("Properties") + cards : ""}
    ${subs.length ? H("Crew notes") + notesHtml : ""}
    <div style="font-size:11px;color:#9ca3af;margin-top:24px;">One combined report for the day, sent automatically at 11:59pm.</div></div>`;

  const text = [`Pleasantview daily report — ${prettyDate(date)}`, `${items.length} visits, ${crew.size} crew, ${totalPhotos} photos`, "",
    ...items.map((it) => `${it.name} (${it.address}) ${it.season}\n` + it.groups.map((g) => `  ${g.by} ${span(g)}: ${g.tasks.join(", ")}`).join("\n") + locText(it.loc) + (it.undone.length ? `\n  Not done: ${it.undone.join(", ")}` : "") + (it.notes ? `\n  Notes: ${it.notes}` : "")),
    ...(subs.length ? ["", "Crew notes:", ...subs.map((s) => `  ${s.employee}: ${s.notes || "—"}`)] : [])].join("\n");

  try {
    const transporter = nodemailer.createTransport({ service: "gmail", auth: { user, pass } });
    await transporter.sendMail({
      from: `"Pleasantview Property Services" <${user}>`,
      to: Deno.env.get("REPORT_TO") || "Reports@pleasantviewservices.ca",
      subject: `Daily report — ${new Date(date + "T12:00:00").toLocaleDateString("en-CA", { weekday: "short", month: "short", day: "numeric", year: "numeric" })} · ${items.length} visit${items.length === 1 ? "" : "s"}`,
      text, html,
    });
    if (!manual) await sb.from("app_data").upsert({ key: `pps-dsent-${date}`, value: { at: new Date().toISOString() }, updated_at: new Date().toISOString() });
    return json({ ok: true, sent: true, visits: items.length, notes: subs.length });
  } catch (e) {
    return json({ ok: false, error: "Gmail rejected the message: " + String((e as Error).message || e).slice(0, 160) }, 502);
  }
});
